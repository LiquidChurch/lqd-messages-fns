<li id="gc-sermon-resources-list-item-<?php $this->output( 'index', 'absint' ); ?>" class="gc-sermon-resources-list-item gc-sermon-resources-list-item-<?php $this->output( 'type', 'esc_attr' ); ?>">
	<?php $this->output( 'item' ); ?>
</li>
