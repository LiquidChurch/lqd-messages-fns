# LiquidChurch Functionality Includes #
http://www.liquidchurch.com/
Copyright (c) 2016-2016 Liquid Church
Copyright (c) 2016 Justin Sternberg
Licensed under the GPLv2 license.

Additional PHP functionality goes here.