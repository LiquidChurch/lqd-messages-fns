# LiquidChurch Functionality Assets #
http://www.liquidchurch.com/
Copyright (c) 2016-2017 Liquid Church
Copyright (c) 2016 Justin Sternberg
Licensed under the GPLv2 license.

Assets such as styles, javascript, and images.