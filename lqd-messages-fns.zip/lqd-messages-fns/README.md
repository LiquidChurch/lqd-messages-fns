# lqd-messages-fns
Provides additional functionality to the Liquid Messages plugin. Eventually this functionality will be integrated directly into plugin.

# Fork of Liquid-Church-Functionality

Justin Sternberg (@jsternberg) created the core GC-Sermons WordPress plugin. Liquid Church then contracted Justin to significantly expand the plugin. Since then Liquid Church has contracted Suraj Gupta to continue to expand and refine the plugin. Development of the plugin has occurred under the direction of Dave Mackey (@davidshq).
